
import http.server, socketserver, threading, json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
PORT = 8124

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)
    def log_message(self, *args):
        pass

httpd = socketserver.TCPServer(("127.0.0.1", PORT), Handler)
thread = threading.Thread(target=httpd.serve_forever, daemon=True)
thread.start()

lookup_map = {
    'BR8 7RE': { 'postcode': 'BR8 7RE', 'longitude': 0.178871, 'latitude': 51.411831 },
    'ME19 5DP': { 'postcode': 'ME19 5DP', 'longitude': 0.409161, 'latitude': 51.296444 },
    'SW1A 1AA': { 'postcode': 'SW1A 1AA', 'longitude': -0.141588, 'latitude': 51.501009 },
    'M1 1AE': { 'postcode': 'M1 1AE', 'longitude': -2.235143, 'latitude': 53.479251 },
    'LS1 4AP': { 'postcode': 'LS1 4AP', 'longitude': -1.548567, 'latitude': 53.799681 },
    'B1 1TB': { 'postcode': 'B1 1TB', 'longitude': -1.907470, 'latitude': 52.479055 },
    'EH1 1YZ': { 'postcode': 'EH1 1YZ', 'longitude': -3.190404, 'latitude': 55.952345 },
    'CF10 1EP': { 'postcode': 'CF10 1EP', 'longitude': -3.176480, 'latitude': 51.481583 },
    'G2 1DY': { 'postcode': 'G2 1DY', 'longitude': -4.257630, 'latitude': 55.860916 },
    'BT1 5GS': { 'postcode': 'BT1 5GS', 'longitude': -5.929939, 'latitude': 54.597285 },
    'EX1 1RS': { 'postcode': 'EX1 1RS', 'longitude': -3.533899, 'latitude': 50.723629 },
    'PL1 1LP': { 'postcode': 'PL1 1LP', 'longitude': -4.148383, 'latitude': 50.371392 },
}

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()

    def handle_route(route):
        data = json.loads(route.request.post_data or '{}')
        results = []
        for pc in data.get('postcodes', []):
            results.append({'query': pc, 'result': lookup_map.get(pc.upper())})
        route.fulfill(status=200, content_type='application/json', body=json.dumps({'status': 200, 'result': results}))

    page.route('https://api.postcodes.io/postcodes?filter=postcode,longitude,latitude', handle_route)
    page.goto(f'http://127.0.0.1:{PORT}/index.html')
    page.click('#loadSample')
    page.click('#renderMap')
    page.wait_for_timeout(800)

    stats = page.locator('#stats').inner_text()
    legend = page.locator('#legend').inner_text()
    circles = page.locator('#heatPoints circle').count()

    assert 'Plotted rows:' in stats, stats
    assert 'Legend' in legend, legend
    assert circles >= 8, circles

    page.fill('#dataInput', '2026-03-01, INVALID\n2026-03-01, BR8 7RE')
    page.click('#renderMap')
    page.wait_for_timeout(300)
    stats2 = page.locator('#stats').inner_text()
    assert 'Invalid input rows: 1' in stats2, stats2

    browser.close()

httpd.shutdown()
print('All tests passed.')

const http = require('http');
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const root = __dirname;
const port = 8123;

const server = http.createServer((req, res) => {
  let filePath = path.join(root, req.url === '/' ? '/index.html' : req.url);
  if (!filePath.startsWith(root)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    const ext = path.extname(filePath).toLowerCase();
    const types = { '.html': 'text/html', '.js': 'application/javascript', '.md': 'text/markdown', '.bat': 'text/plain' };
    res.writeHead(200, { 'Content-Type': types[ext] || 'text/plain' });
    res.end(data);
  });
});

(async () => {
  server.listen(port);
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();

  await page.route('https://api.postcodes.io/postcodes?filter=postcode,longitude,latitude', async route => {
    const body = JSON.parse(route.request().postData() || '{}');
    const results = (body.postcodes || []).map(pc => {
      const norm = pc.toUpperCase();
      const map = {
        'BR8 7RE': { postcode: 'BR8 7RE', longitude: 0.178871, latitude: 51.411831 },
        'ME19 5DP': { postcode: 'ME19 5DP', longitude: 0.409161, latitude: 51.296444 },
        'SW1A 1AA': { postcode: 'SW1A 1AA', longitude: -0.141588, latitude: 51.501009 },
        'M1 1AE': { postcode: 'M1 1AE', longitude: -2.235143, latitude: 53.479251 },
        'LS1 4AP': { postcode: 'LS1 4AP', longitude: -1.548567, latitude: 53.799681 },
        'B1 1TB': { postcode: 'B1 1TB', longitude: -1.90747, latitude: 52.479055 },
        'EH1 1YZ': { postcode: 'EH1 1YZ', longitude: -3.190404, latitude: 55.952345 },
        'CF10 1EP': { postcode: 'CF10 1EP', longitude: -3.17648, latitude: 51.481583 },
        'G2 1DY': { postcode: 'G2 1DY', longitude: -4.25763, latitude: 55.860916 },
        'BT1 5GS': { postcode: 'BT1 5GS', longitude: -5.929939, latitude: 54.597285 },
        'EX1 1RS': { postcode: 'EX1 1RS', longitude: -3.533899, latitude: 50.723629 },
        'PL1 1LP': { postcode: 'PL1 1LP', longitude: -4.148383, latitude: 50.371392 }
      };
      return { query: pc, result: map[norm] || null };
    });
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ status: 200, result: results })
    });
  });

  await page.goto(`http://127.0.0.1:${port}/`);
  await page.click('#loadSample');
  await page.click('#renderMap');
  await page.waitForTimeout(600);

  const statsText = await page.locator('#stats').innerText();
  const legendText = await page.locator('#legend').innerText();
  const circles = await page.locator('#heatPoints circle').count();

  if (!statsText.includes('Plotted rows:')) throw new Error('Stats missing plotted rows');
  if (!legendText.includes('Legend')) throw new Error('Legend missing');
  if (circles < 8) throw new Error(`Expected multiple circles, got ${circles}`);

  await page.fill('#dataInput', '2026-03-01, INVALID\n2026-03-01, BR8 7RE');
  await page.click('#renderMap');
  await page.waitForTimeout(300);
  const stats2 = await page.locator('#stats').innerText();
  if (!stats2.includes('Invalid input rows: 1')) throw new Error('Invalid row count failed');

  console.log('All tests passed.');
  await browser.close();
  server.close();
})();
